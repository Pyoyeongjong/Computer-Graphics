"use strict";

var gl;
var theta = [0, 0, 0];
var translateVector = [0, 0, 0];
var scaleVector = [1, 1, 1];
var xAxis = 0;
var yAxis = 1;
var zAxis = 2;
var speed = 0.01;
var direction = true;
var isrotate = true;
var modelViewMatrixLoc, projectionMatrixLoc;
var modelViewMatrix, projectionMatrix;

window.onload = function init()
{
    // 캔버스 생성 - 이거 HTML에서 가져오네. <canvas id="gl-canvas" width="512" height="512">
    var canvas = document.getElementById( "gl-canvas" );
    document.getElementById("DirectionX").onclick = function(){
        if(theta[xAxis] == 0){
            theta[xAxis] += 1;
        }
        else{
            theta[xAxis] = 0;
        }
    }
    document.getElementById("DirectionY").onclick = function(){
        if(theta[yAxis] == 0){
            theta[yAxis] += 1;
        }
        else{
            theta[yAxis] = 0;
        }

    }
    document.getElementById("DirectionZ").onclick = function(){
        if(theta[zAxis] == 0){
            theta[zAxis] += 1;
        }
        else{
            theta[zAxis] = 0;
        }

    }
    document.getElementById("TransUp").onclick = function(){
        translateVector[yAxis] += 0.1;

    }
    document.getElementById("TransDown").onclick = function(){
        translateVector[yAxis] -= 0.1;

    }
    document.getElementById("TransLeft").onclick = function(){
        translateVector[xAxis] -= 0.1;

    }
    document.getElementById("TransRight").onclick = function(){
        translateVector[xAxis] += 0.1;

    }
    document.getElementById("TransFront").onclick = function(){
        translateVector[zAxis] += 0.1;

    }
    document.getElementById("TransBack").onclick = function(){
        translateVector[zAxis] -= 0.1;
    }

    document.getElementById("scalex").onclick = function(){
        scaleVector = [1, 1, 1];
        scaleVector[xAxis] += 0.1;
        modelViewMatrix = mult(modelViewMatrix, scalem(scaleVector[xAxis],
                                                        scaleVector[yAxis],
                                                        scaleVector[zAxis]));
    }
    document.getElementById("scaley").onclick = function(){
        scaleVector = [1, 1, 1];
        scaleVector[yAxis] += 0.1;
        modelViewMatrix = mult(modelViewMatrix, scalem(scaleVector[xAxis],
            scaleVector[yAxis],
            scaleVector[zAxis]));;
    }
    document.getElementById("scalez").onclick = function(){
        scaleVector = [1, 1, 1];
        scaleVector[zAxis] += 0.1;
        modelViewMatrix = mult(modelViewMatrix, scalem(scaleVector[xAxis],
            scaleVector[yAxis],
            scaleVector[zAxis]));
    }

    document.getElementById("scalexm").onclick = function(){
        scaleVector = [1, 1, 1];
        scaleVector[xAxis] -= 0.1;
        modelViewMatrix = mult(modelViewMatrix, scalem(scaleVector[xAxis],
                                                        scaleVector[yAxis],
                                                        scaleVector[zAxis]));
    }
    document.getElementById("scaleym").onclick = function(){
        scaleVector = [1, 1, 1];
        scaleVector[yAxis] -= 0.1;
        modelViewMatrix = mult(modelViewMatrix, scalem(scaleVector[xAxis],
            scaleVector[yAxis],
            scaleVector[zAxis]));
    }
    document.getElementById("scalezm").onclick = function(){
        scaleVector = [1, 1, 1];
        scaleVector[zAxis] -= 0.1;
        modelViewMatrix = mult(modelViewMatrix, scalem(scaleVector[xAxis],
            scaleVector[yAxis],
            scaleVector[zAxis]));
    }

    // 캔버스 붙이기
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    // 점 데이터
    var vertices = [
        // P with Triangles
        vec3(-0.8, 0.5, 0),
        vec3(-0.8, -0.5, 0),
        vec3(-0.6, -0.5, 0),
    
        vec3(-0.6, -0.5, 0),
        vec3(-0.6, 0.5, 0),
        vec3(-0.8, 0.5, 0),
    
        vec3(-0.6, 0.5, 0),
        vec3(-0.4, 0.5, 0),
        vec3(-0.4, 0.3, 0),
    
        vec3(-0.4, 0.3, 0),
        vec3(-0.6, 0.3, 0),
        vec3(-0.6, 0.5, 0),
    
        vec3(-0.4, 0.5, 0),
        vec3(-0.4, 0.3, 0),
        vec3(-0.2, 0.3, 0),
    
        vec3(-0.2, 0.3, 0),
        vec3(-0.2, 0.1, 0),
        vec3(-0.4, 0.3, 0),
    
        vec3(-0.4, 0.3, 0),
        vec3(-0.4, 0.1, 0),
        vec3(-0.2, 0.1, 0),
    
        vec3(-0.2, 0.1, 0),
        vec3(-0.4, 0.1, 0),
        vec3(-0.4, -0.1, 0),
    
        vec3(-0.4, -0.1, 0),
        vec3(-0.4, 0.1, 0),
        vec3(-0.6, -0.1, 0),
    
        vec3(-0.6, -0.1, 0),
        vec3(-0.6, 0.1, 0),
        vec3(-0.4, 0.1, 0),
    
        // Y with Lines
        vec3(-0.1, 0.5, 0),
        vec3(0, 0., 0),
        vec3(0, 0., 0),
        vec3(0., -0.5, 0),
        vec3(0, 0., 0),
        vec3(0.1, 0.5, 0),
    
        // J with Points
        vec3(0.2, 0.5, 0),
        vec3(0.3, 0.5, 0),
        vec3(0.4, 0.5, 0),
        vec3(0.5, 0.5, 0),
        vec3(0.6, 0.5, 0),
        vec3(0.4, 0.4, 0),
        vec3(0.4, 0.3, 0),
        vec3(0.4, 0.2, 0),
        vec3(0.4, 0.1, 0),
        vec3(0.4, 0., 0),
        vec3(0.4, -0.1, 0),
        vec3(0.4, -0.2, 0),
        vec3(0.35, -0.25, 0),
        vec3(0.3, -0.3, 0),
        vec3(0.25, -0.25, 0),
        vec3(0.2, -0.2, 0),
    ];

    var vertice = [
        // Simple triangle
        vec3(-0.5, -0.5, 0.0),
        vec3(0.5, -0.5, 0.0),
        vec3(0.0, 0.5, 0.0)
    ];
    

    //
    //  Configure WebGL
    //
    // 캔버스 크기 설정
    gl.viewport( 0, 0, canvas.width, canvas.height );
    // 백그라운드 설정
    gl.clearColor( 1., 1., 1., 1.0 );
    // z-buffer
    gl.enable(gl.DEPTH_TEST);

    //  Load shaders and initialize attribute buffers

    var program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );

    var u_FragColor = gl.getUniformLocation(program, 'u_FragColor');
    gl.uniform4f(u_FragColor, 1.0, 0.0, 0.0, 1.0 );

    // ProjectionMatrix
    var fovy = 60.0;
    var aspect = canvas.width / canvas.height;
    var near = 0.1;
    var far = 10.0;
    projectionMatrix = perspective(fovy, aspect, near, far);

    // ModelViewMatrix
    var eye = vec3(0, 0, 3);
    var at = vec3(0, 0, 0);
    var up = vec3(0, 1, 0);
    modelViewMatrix = lookAt(eye, at, up);

    modelViewMatrixLoc = gl.getUniformLocation(program, "modelViewMatrix");
    projectionMatrixLoc = gl.getUniformLocation(program, "projectionMatrix");

    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix));

    // Load the data into the GPU
    // GPU 버퍼에 데이터를 보내야 한다..!
    var bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW );

    // Associate out shader variables with our data buffer
    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition );

    render();
};


function render() {
    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    if(theta[xAxis]==0){
        theta[xAxis];
    }
    modelViewMatrix = mult(modelViewMatrix, translate(translateVector));
    modelViewMatrix = mult(modelViewMatrix, rotateX(theta[xAxis]));
    modelViewMatrix = mult(modelViewMatrix, rotateY(theta[yAxis]));
    modelViewMatrix = mult(modelViewMatrix, rotateZ(theta[zAxis]));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));

    translateVector = [0, 0, 0];
    
    gl.drawArrays(gl.TRIANGLES, 0, 30);
    gl.drawArrays(gl.LINES, 30, 6)
    gl.drawArrays(gl.POINTS, 36, 16)
    requestAnimationFrame(render);
}
