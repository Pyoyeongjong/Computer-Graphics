"use strict";

var gl;
var theta = 0.0;
var speed = 0.01;
var thetaLoc;
var direction = true;
var isrotate = true;

window.onload = function init()
{
    // 캔버스 생성 - 이거 HTML에서 가져오네. <canvas id="gl-canvas" width="512" height="512">
    var canvas = document.getElementById( "gl-canvas" );
    document.getElementById("Direction").onclick = function(){
        direction = !direction;
    }
    document.getElementById("Controls").onclick = function(event){
        switch(event.target.index){
            case 0:
                isrotate = false;
                speed = 0.01
                break;

            case 1:
                isrotate = true;
                speed = speed * 2;
                break;

            case 2:
                speed = speed / 2;
                isrotate = true;
                break;

        }
    }
    // 캔버스 붙이기
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    // 점 데이터
    var vertices = [
        // P with Triangles
        vec2(-0.8, 0.5),
        vec2(-0.8, -0.5),
        vec2(-0.6, -0.5),
        
        vec2(-0.6, -0.5),
        vec2(-0.6, 0.5),
        vec2(-0.8, 0.5),
        
        vec2(-0.6, 0.5),
        vec2(-0.4, 0.5),
        vec2(-0.4, 0.3),
        
        vec2(-0.4, 0.3),
        vec2(-0.6, 0.3),
        vec2(-0.6, 0.5),
        
        vec2(-0.4, 0.5),
        vec2(-0.4, 0.3),
        vec2(-0.2, 0.3),
        
        vec2(-0.2, 0.3),
        vec2(-0.2, 0.1),
        vec2(-0.4, 0.3),
        
        vec2(-0.4, 0.3),
        vec2(-0.4, 0.1),
        vec2(-0.2, 0.1),
        
        vec2(-0.2, 0.1),
        vec2(-0.4, 0.1),
        vec2(-0.4, -0.1),
        
        vec2(-0.4, -0.1),
        vec2(-0.4, 0.1),
        vec2(-0.6, -0.1),
        
        vec2(-0.6, -0.1),
        vec2(-0.6, 0.1),
        vec2(-0.4, 0.1),

        // Y with Lines
        vec2(-0.1, 0.5),
        vec2(0, 0.),
        vec2(0, 0.),
        vec2(0., -0.5),
        vec2(0, 0.),
        vec2(0.1, 0.5),

        // J with Points
        vec2(0.2, 0.5),
        vec2(0.3, 0.5),
        vec2(0.4, 0.5),
        vec2(0.5, 0.5),
        vec2(0.6, 0.5),
        vec2(0.4, 0.4),
        vec2(0.4, 0.3),
        vec2(0.4, 0.2),
        vec2(0.4, 0.1),
        vec2(0.4, 0.),
        vec2(0.4, -0.1),
        vec2(0.4, -0.2),
        vec2(0.35, -0.25),
        vec2(0.3, -0.3),
        vec2(0.25, -0.25),
        vec2(0.2, -0.2),
    ];

    //
    //  Configure WebGL
    //
    // 캔버스 크기 설정
    gl.viewport( 0, 0, canvas.width, canvas.height );
    // 백그라운드 설정
    gl.clearColor( 1., 1., 1., 1.0 );

    //  Load shaders and initialize attribute buffers

    var program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );

    var u_FragColor = gl.getUniformLocation(program, 'u_FragColor');
    window.onkeydown = function(event){
        
        var key = String.fromCharCode(event.keyCode);
        switch(key){
            case '1':
                gl.uniform4f(u_FragColor, 1.0, 0.0, 0.0, 1.0 );
                break;
            
            case '2':
                gl.uniform4f(u_FragColor, 0.0, 1.0, 0.0, 1.0 );
                break;

            case '3':
                gl.uniform4f(u_FragColor, 0.0, 0.0, 1.0, 1.0 );
                break;
        }

    }
    gl.uniform4f(u_FragColor, 1.0, 0.0, 0.0, 1.0 );
    // Load the data into the GPU
    // GPU 버퍼에 데이터를 보내야 한다..!
    var bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW );


    // Associate out shader variables with our data buffer

    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition );

    thetaLoc = gl.getUniformLocation(program, "theta");

    render();
};


function render() {
    gl.clear( gl.COLOR_BUFFER_BIT );
    
    if (!isrotate)
        theta = 0;
    else
        theta += direction? speed : -speed;
    gl.uniform1f(thetaLoc, theta);
    gl.drawArrays( gl.TRIANGLES, 0, 30);
    gl.drawArrays(gl.LINES, 30, 6)
    gl.drawArrays(gl.POINTS, 36, 16)

    window.requestAnimationFrame(render);
}
